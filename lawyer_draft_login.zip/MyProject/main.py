from supabase import create_client
from config import supabase_url, supabase_API_key

# Initialize Supabase client
supabase = create_client(supabase_url, supabase_API_key)

# Get user input
email = input("Enter your email: ")
password = input("Enter your password: ")

try:
    # Attempt to sign up the user
    result = supabase.auth.sign_up({
        "email": email,
        "password": password
    })

    if result.user:
        print("✅ Signup successful!")
        print("User ID:", result.user.id)
    else:
        print("❗ Signup failed. No user object returned.")
        print("Response:", result)

except Exception as e:
    print("❌ An error occurred during signup.")
    print("Error:", e)
